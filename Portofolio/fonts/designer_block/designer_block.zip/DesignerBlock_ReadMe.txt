
=== DESIGNER BLOCK ===

Keith Bates / K-Type © 2002, 2010 (version 4.01)
www.k-type.com    -    info@k-type.com

A display font inspired by Designer Shock, Designers Republic and that cool 90s designer thing.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------